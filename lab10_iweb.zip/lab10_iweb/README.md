# LAB10_IWEB - Sistema de Registro de Cursos (DTO)

## Estructura del proyecto

```
src/main/
├── java/com/example/
│   ├── dto/
│   │   ├── DocenteDTO.java
│   │   └── CursoDTO.java
│   ├── dao/
│   │   ├── DaoBase.java
│   │   ├── DocenteDAO.java
│   │   └── CursoDAO.java
│   └── servlet/
│       └── CursoServlet.java
└── webapp/
    ├── index.jsp        <- formulario de registro
    └── resultado.jsp     <- tarjeta de confirmacion
pom.xml
lab10_iweb.sql            <- script de base de datos (con el error de comillas corregido)
```

## Pasos para correr el proyecto

1. Ejecuta el script `lab10_iweb.sql` en MySQL Workbench.
2. Abre `DaoBase.java` y cambia la contraseña de tu MySQL en la variable `pass`.
3. Crea un proyecto Maven Web Application en IntelliJ (Jakarta EE 10, solo Servlet).
4. Copia las carpetas `dto`, `dao`, `servlet` dentro de tu paquete `com.example`.
5. Copia `index.jsp` y `resultado.jsp` dentro de `webapp`.
6. Reemplaza tu `pom.xml` con el que se incluye aqui.
7. Carga las dependencias de Maven (icono 🔄).
8. Ejecuta con Tomcat y abre `http://localhost:8080/<nombre_proyecto>/index.jsp`.

## Resumen de lo implementado por ejercicio

- **Ejercicio 1:** `DocenteDTO` y `CursoDTO`, ambos con constructor vacio, constructor
  con parametros, getters y setters. `CursoDTO` contiene un `DocenteDTO` como atributo
  para representar la relacion 1 a muchos.
- **Ejercicio 2:** `index.jsp` con formulario POST hacia `/registrarCurso`, el campo
  Docente es un `<select>` (menu desplegable) cargado dinamicamente desde la BD.
- **Ejercicio 3:** `CursoServlet` mapeado con `@WebServlet("/registrarCurso")`.
  En `doPost()`: recupera parametros, construye los DTOs, llama a `CursoDAO.registrar()`,
  guarda el `CursoDTO` con `request.setAttribute()` y hace forward a `resultado.jsp`.
  `CursoDAO.registrar(CursoDTO curso)` inserta el curso usando `PreparedStatement`.
- **Ejercicio 4:** `resultado.jsp` recupera el DTO con `request.getAttribute()` y
  muestra una tarjeta con codigo, nombre, creditos y el nombre del docente asignado
  (obtenido del objeto `DocenteDTO` anidado dentro del `CursoDTO`).
