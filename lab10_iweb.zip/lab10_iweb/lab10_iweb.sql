CREATE DATABASE IF NOT EXISTS lab10_iweb;
USE lab10_iweb;

CREATE TABLE docente (
  id_docente INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  especialidad VARCHAR(100)
);

CREATE TABLE curso (
  id_curso INT PRIMARY KEY AUTO_INCREMENT,
  codigo VARCHAR(10) NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  creditos INT NOT NULL,
  id_docente INT,
  FOREIGN KEY (id_docente) REFERENCES docente(id_docente)
);

-- Datos iniciales obligatorios
-- NOTA: en el PDF original faltaba una comilla en 'Electronica', aqui ya esta corregido
INSERT INTO docente (nombre, especialidad) VALUES ('Juan Pérez', 'Telecomunicaciones');
INSERT INTO docente (nombre, especialidad) VALUES ('María Gómez', 'Electronica');
