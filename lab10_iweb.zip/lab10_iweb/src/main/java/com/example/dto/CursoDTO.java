package com.example.dto;

public class CursoDTO {

    private int idCurso;
    private String codigo;
    private String nombre;
    private int creditos;

    // Objeto DocenteDTO como atributo, representa la relación 1 a muchos
    private DocenteDTO docente;

    // Constructor vacío
    public CursoDTO() {
    }

    // Constructor con parámetros
    public CursoDTO(int idCurso, String codigo, String nombre,
                     int creditos, DocenteDTO docente) {
        this.idCurso = idCurso;
        this.codigo = codigo;
        this.nombre = nombre;
        this.creditos = creditos;
        this.docente = docente;
    }

    // Getters
    public int getIdCurso() {
        return idCurso;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public DocenteDTO getDocente() {
        return docente;
    }

    // Setters
    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public void setDocente(DocenteDTO docente) {
        this.docente = docente;
    }
}
