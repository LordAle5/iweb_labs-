package com.example.dto;

public class DocenteDTO {

    private int idDocente;
    private String nombre;
    private String especialidad;

    // Constructor vacío
    public DocenteDTO() {
    }

    // Constructor con parámetros
    public DocenteDTO(int idDocente, String nombre, String especialidad) {
        this.idDocente = idDocente;
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    // Getters
    public int getIdDocente() {
        return idDocente;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    // Setters
    public void setIdDocente(int idDocente) {
        this.idDocente = idDocente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
