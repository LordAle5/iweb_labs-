package com.example.dao;

import com.example.dto.DocenteDTO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DocenteDAO extends DaoBase {

    // Listar todos los docentes, usado para el menu desplegable del formulario
    public ArrayList<DocenteDTO> listarDocentes() {
        ArrayList<DocenteDTO> lista = new ArrayList<>();
        try {
            Connection conn = getConnection();
            Statement stmt  = conn.createStatement();
            ResultSet rs    = stmt.executeQuery(
                "SELECT id_docente, nombre, especialidad FROM docente");

            while (rs.next()) {
                DocenteDTO d = new DocenteDTO();
                d.setIdDocente(rs.getInt("id_docente"));
                d.setNombre(rs.getString("nombre"));
                d.setEspecialidad(rs.getString("especialidad"));
                lista.add(d);
            }
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error SQL: " + e.getMessage());
        }
        return lista;
    }

    // Obtener un docente por su ID, usado luego de registrar el curso
    // para mostrar el nombre del docente asignado en resultado.jsp
    public DocenteDTO obtenerPorId(int idDocente) {
        DocenteDTO d = null;
        try {
            Connection conn = getConnection();
            String sql = "SELECT id_docente, nombre, especialidad FROM docente WHERE id_docente = ?";
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idDocente);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                d = new DocenteDTO();
                d.setIdDocente(rs.getInt("id_docente"));
                d.setNombre(rs.getString("nombre"));
                d.setEspecialidad(rs.getString("especialidad"));
            }
            conn.close();
        } catch (SQLException e) {
            System.out.println("Error SQL: " + e.getMessage());
        }
        return d;
    }
}
