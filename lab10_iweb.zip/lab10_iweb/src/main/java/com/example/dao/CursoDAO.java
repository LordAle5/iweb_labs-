package com.example.dao;

import com.example.dto.CursoDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CursoDAO extends DaoBase {

    // Registrar un curso nuevo usando PreparedStatement
    // Recibe el CursoDTO completo (incluye el DocenteDTO dentro)
    public void registrar(CursoDTO curso) {
        try {
            Connection conn = getConnection();

            String sql = "INSERT INTO curso (codigo, nombre, creditos, id_docente) " +
                         "VALUES (?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, curso.getCodigo());
            ps.setString(2, curso.getNombre());
            ps.setInt(3, curso.getCreditos());
            // El id del docente lo sacamos del objeto DocenteDTO dentro del CursoDTO
            ps.setInt(4, curso.getDocente().getIdDocente());

            ps.executeUpdate(); // INSERT -> executeUpdate
            conn.close();

        } catch (SQLException e) {
            System.out.println("Error SQL: " + e.getMessage());
        }
    }
}
