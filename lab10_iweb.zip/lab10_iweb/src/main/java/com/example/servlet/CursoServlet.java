package com.example.servlet;

import com.example.dao.CursoDAO;
import com.example.dao.DocenteDAO;
import com.example.dto.CursoDTO;
import com.example.dto.DocenteDTO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

// Mapeo exacto que pide el lab
@WebServlet("/registrarCurso")
public class CursoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // a. Recuperar los parametros enviados desde el formulario JSP
        String codigo       = request.getParameter("codigo");
        String nombre        = request.getParameter("nombre");
        int creditos          = Integer.parseInt(request.getParameter("creditos"));
        int idDocente         = Integer.parseInt(request.getParameter("idDocente"));

        // b. Crear instancias de los DTOs y asignar la informacion recogida
        DocenteDAO docenteDAO = new DocenteDAO();
        DocenteDTO docente    = docenteDAO.obtenerPorId(idDocente);

        CursoDTO curso = new CursoDTO();
        curso.setCodigo(codigo);
        curso.setNombre(nombre);
        curso.setCreditos(creditos);
        curso.setDocente(docente);

        // c. Invocar el metodo registrar del CursoDAO
        CursoDAO cursoDAO = new CursoDAO();
        cursoDAO.registrar(curso);

        // d. Almacenar el CursoDTO completo utilizando request.setAttribute()
        request.setAttribute("curso", curso);

        // e. Realizar un forward hacia resultado.jsp
        RequestDispatcher view = request.getRequestDispatcher("resultado.jsp");
        view.forward(request, response);
    }

    // GET -> redirige al formulario principal (index.jsp)
    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
    }
}
